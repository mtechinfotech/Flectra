# Part of Flectra See LICENSE file for full copyright and licensing details.

from . import res_config_settings
from . import account_invoice
from . import note_issue_reason
from . import product_uom
from . import res_company
from . import res_partner
