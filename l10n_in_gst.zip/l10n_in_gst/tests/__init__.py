# Part of Flectra See LICENSE file for full copyright and licensing details.

from . import test_gst_common
from . import test_account_invoice
from . import test_res_partner
from . import test_res_company
from . import test_gst_summary_reports
