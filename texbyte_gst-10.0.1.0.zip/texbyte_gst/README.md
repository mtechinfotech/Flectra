TeXByte GST Solution for Odoo 10
================================

This module adds support for India GST tax system for Odoo version 10.

Copyright 2017--2018 TeXByte Solutions ʟʟᴘ.

Licensed under LGPLv3, see LICENSE file for details.
