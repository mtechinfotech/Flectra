# -*- coding: utf-8 -*-
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

#from . import models
from . import product
from . import hsncode
from . import res_company
from . import res_partner
from . import res_country
from . import sale
from . import purchase
from . import invoice
from . import account_tax
